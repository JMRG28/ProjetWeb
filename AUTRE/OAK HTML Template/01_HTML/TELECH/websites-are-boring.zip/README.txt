A Pen created at CodePen.io. You can find this one at https://codepen.io/flatking/pen/qjEpRY.

 Every time I try and redesign my portfolio it looks so boring. So I threw this together, websites aren't boring I'm just bad at design