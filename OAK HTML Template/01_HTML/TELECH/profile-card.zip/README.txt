A Pen created at CodePen.io. You can find this one at https://codepen.io/JavaScriptJunkie/pen/jvRGZy.

 Responsive and colorful Profile Card concept. I hope you like it.