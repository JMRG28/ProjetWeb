A Pen created at CodePen.io. You can find this one at https://codepen.io/kathykato/pen/QaVeGK.

 Notification UI made with Vue.js that uses CSS Grid Layout (and Flexbox as a fallback). Random users are generated with an API.